<?php
include_once "wechatCommon.php";

?>