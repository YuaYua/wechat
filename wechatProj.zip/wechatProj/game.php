<?php
	include_once "wechatCommon.php";
	$code=$_GET["code"];
//	echo $code;
	$api="https://api.weixin.qq.com/sns/oauth2/access_token?appid=$appid&secret=$appsecret&code=$code&grant_type=authorization_code";
	$result=httpGet($api);
	$arr=json_decode($result,true);
	$access_token=$arr["access_token"];
	$openid=$arr["openid"];
//	var_dump($result);
	$userUrl="https://api.weixin.qq.com/sns/userinfo?access_token=$access_token&openid=$openid&lang=zh_CN";
	$json=httpGet($userUrl);
	var_dump($json);
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title></title>
		<style type="text/css">
			*{
				margin: 0;
				padding: 0;
			}
			#main{
				margin: 10px auto;
				width: 500px;
				text-align: center;
			}
			#wrap{
				height: 200px;
				width: 100%;
				line-height: 200px;
				border: 1px solid black;
			}
			.btn1{
				margin-top: 50px;
			}
		</style>
	</head>
	<body>
		<div id="main">
			<div id="wrap">
				<p id="num">1</p>
			</div>
			<button id="start" class="btn1">开始</button>
			<button id="stop" class="btn1">停止</button>
			<ul id="rankList"></ul>
		</div>
		<div id="test">
			
		</div>
	</body>
	<script src="JQuery-3.1.1.min.js" type="text/javascript" charset="utf-8"></script>
	<script type="text/javascript">
		var num=document.getElementById("num");
		var start=document.getElementById("start");
		var stop=document.getElementById("stop");
		var test=document.getElementById("test");
		
		var timer=null;
		//开始就要得到登录者的信息
		
		
		//随机数1~100
		function rand(max,min){
			return parseInt(Math.random()*(max-min+1)+min);
		}
		start.onclick=function(){
			timer=setInterval(function(){
				n=rand(100,1);
				num.innerHTML=n;
			},30);
		}
		stop.onclick=function(){
			clearInterval(timer);
		}
		
</script>
</html>
